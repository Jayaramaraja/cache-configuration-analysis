***********************************
Project #1
***********************************
Optimizaton of Cache
-----------------------------------
This folder contains the python script to execute the setup valid combinations and scripts used for the analysis of various sets of cache parameters graph.